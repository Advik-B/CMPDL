onEvent('recipes', event => {
    event.custom({
        'type':'occultism:spirit_fire',
        'ingredient':{'item':'allthecompressed:netherrack_block_1x'},
        'result':{'item':'occultism:iesnium_ore_natural'}
    })
})