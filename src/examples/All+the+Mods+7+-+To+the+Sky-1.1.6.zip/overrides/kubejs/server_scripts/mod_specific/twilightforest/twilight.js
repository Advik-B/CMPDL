onEvent('recipes', event => {
    event.remove({ id: 'twilightforest:uncrafting_table' })
})
