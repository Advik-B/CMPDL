onEvent('recipes',event => {
    event.remove({id:'reliquary:rod_of_lyssa'})
})