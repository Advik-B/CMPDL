onEvent('recipes',event => {
    event.remove({id:'apotheosis:fletching/iron_mining_arrow'}),
    event.remove({id:'apotheosis:fletching/diamond_mining_arrow'}),
    event.remove({id:'apotheosis:fletching/explosive_arrow'})
})